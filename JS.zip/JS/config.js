import { CONTRACT_ABI } from "../abi/abi.json";

export const CONTRACT_ADDRESS = "0x586491D4686c386e63cD1534869cf4b1B5e4b250";

export { CONTRACT_ABI };

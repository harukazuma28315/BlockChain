import { ethers } from "https://cdn.jsdelivr.net/npm/ethers@6.13.1/+esm";
import { CONTRACT_ADDRESS, CONTRACT_ABI } from "./config.js";

let provider;
let signer;
let contract;

export async function connectWallet() {
  if (!window.ethereum) {
    alert("Vui lòng cài MetaMask!");
    return;
  }

  try {
    provider = new ethers.BrowserProvider(window.ethereum);

    await provider.send("eth_requestAccounts", []);

    signer = await provider.getSigner();

    const walletAddress = await signer.getAddress();

    console.log("Đã kết nối:", walletAddress);

    alert("Kết nối thành công!");
  } catch (error) {
    console.error(error);

    alert("Không thể kết nối MetaMask.");
  }
}

connectWallet();
